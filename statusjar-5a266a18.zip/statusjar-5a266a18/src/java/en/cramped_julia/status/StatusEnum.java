/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  en.cramped_julia.status.StatusEnum
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  org.bukkit.ChatColor
 */
package en.cramped_julia.status;

import org.bukkit.ChatColor;

/*
 * Exception performing whole class analysis ignored.
 */
public final class StatusEnum
extends Enum<StatusEnum> {
    public static final /* enum */ StatusEnum AFK = new StatusEnum("AFK", 0, "001", "AFK", ChatColor.GRAY);
    public static final /* enum */ StatusEnum NEW = new StatusEnum("NEW", 1, "002", "New", ChatColor.GREEN);
    public static final /* enum */ StatusEnum SEXY = new StatusEnum("SEXY", 2, "003", "Sexy", ChatColor.LIGHT_PURPLE);
    public static final /* enum */ StatusEnum RED = new StatusEnum("RED", 3, "004", "Red", ChatColor.RED);
    public static final /* enum */ StatusEnum BLUE = new StatusEnum("BLUE", 4, "005", "Red", ChatColor.RED);
    public static final /* enum */ StatusEnum GREEN = new StatusEnum("GREEN", 5, "006", "Green", ChatColor.DARK_GREEN);
    public static final /* enum */ StatusEnum YELLOW = new StatusEnum("YELLOW", 6, "007", "Yellow", ChatColor.YELLOW);
    public static final /* enum */ StatusEnum GOLD = new StatusEnum("GOLD", 7, "008", "Gold", ChatColor.GOLD);
    public static final /* enum */ StatusEnum BLACK = new StatusEnum("BLACK", 8, "009", "Black", ChatColor.BLACK);
    public static final /* enum */ StatusEnum BOLD = new StatusEnum("BOLD", 9, "010", "Fat", ChatColor.WHITE);
    private String position;
    private String name;
    private ChatColor color;
    private static final /* synthetic */ StatusEnum[] $VALUES;

    public static StatusEnum[] values() {
        return (StatusEnum[])$VALUES.clone();
    }

    public static StatusEnum valueOf(String name) {
        return (StatusEnum)Enum.valueOf(StatusEnum.class, (String)name);
    }

    private StatusEnum(String position, String name, ChatColor color) {
        this.position = position;
        this.name = name;
        this.color = color;
    }

    public String getPosition() {
        return this.position;
    }

    public String getName() {
        return this.name;
    }

    public ChatColor getColor() {
        return this.color;
    }

    private static /* synthetic */ StatusEnum[] $values() {
        return new StatusEnum[]{AFK, NEW, SEXY, RED, BLUE, GREEN, YELLOW, GOLD, BLACK, BOLD};
    }

    static {
        $VALUES = StatusEnum.$values();
    }
}

